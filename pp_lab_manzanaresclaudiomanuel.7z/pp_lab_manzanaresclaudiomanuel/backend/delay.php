<?php
sleep(2);

echo rand(0,100);
?>